# Como publicar no GitHub Pages

## Estrutura
Este pacote já está pronto para GitHub Pages porque usa apenas 1 arquivo principal: `index.html`.

## Passo a passo
1. Crie um repositório novo no GitHub, por exemplo `presente-luiz`.
2. Envie o arquivo `index.html` para a raiz do repositório.
3. No GitHub, abra `Settings` > `Pages`.
4. Em `Build and deployment`, escolha `Deploy from a branch`.
5. Em `Branch`, selecione `main` e `/ (root)`.
6. Salve.
7. Aguarde alguns segundos até o GitHub gerar a URL pública.

## URL final
A URL costuma ficar assim:
`https://SEU-USUARIO.github.io/NOME-DO-REPO/`

Exemplo:
`https://felippejuan.github.io/presente-luiz/`

## Observações
- Como o arquivo principal já se chama `index.html`, o GitHub Pages abre a página direto.
- Não precisa React, Vite, npm ou build para essa versão.
- As imagens continuam vindo do Cloudinary e a música do Archive.org.
- O botão de salvar voucher usa a impressão do navegador para gerar PDF.

## Se quiser atualizar depois
Basta editar o `index.html`, subir de novo no repositório e o GitHub Pages publica a nova versão.
